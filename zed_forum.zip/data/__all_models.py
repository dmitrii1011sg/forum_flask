from . import users
from . import question
from . import comments
from . import category

"""
Чтобы наша БД видела все модели, что мы сделали
"""